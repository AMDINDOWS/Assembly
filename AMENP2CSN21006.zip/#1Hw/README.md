Please run the following commands.

1) nasm -f elf hw.asm 
2) ld -m elf_i386 hw.o -o hwout
3) ./hwout


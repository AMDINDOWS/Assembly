Instructions:

1) nasm -f elf32 add.s -o test.o
2) gcc test.o -m32 -o test 
3) ./test